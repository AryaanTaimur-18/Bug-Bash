# Bug Bash: DON'T TOUCH edition (Unity, Android)

Unity port of the **Bug Bash** game from the GCC FAST-NUCES Karachi arcade
(`src/app/games/bug-bash`, rules in `games.md`). Portrait phone game, 100% code-generated
art and audio: no imported assets.

## Open it
1. Install **Unity 6 (6000.x)** or **2022.3 LTS or newer** with the *Android Build Support* module (incl. OpenJDK + SDK/NDK).
2. Unity Hub > *Add project from disk* > select this `BugBash` folder. Let it import (first open pulls the Input System package).
3. Menu **Bug Bash > 1. Setup Project for Android**. This sets the Android player settings, creates `Assets/Scenes/Main.unity` and adds it to the build.
4. Open `Assets/Scenes/Main.unity` and press **Play** (set the Game view to a portrait aspect, e.g. 1080x1920). The game builds itself at runtime.
5. **File > Build Settings > Android > Build**, or menu **Bug Bash > 2. Build Android APK** (output: `Builds/BugBash.apk`).
   Headless: `Unity -batchmode -quit -projectPath . -executeMethod BugBash.EditorTools.BugBashBuildTools.BuildAndroidCLI`

## How to play
Tap or swipe bugs to squash them. **Don't touch** working code (green text), features (blue), or `(!) git push --force`.
3 squashes in a row = higher multiplier; x5 = FEVER (double points). Power-ups: + HEAL, SLOW, FIX ALL.
`legacy_monolith.js` boss at 40 s and then about once a minute.
Desktop test keys: Space start/pause, R restart, M mute, Esc/Android Back pause.

## Code map (`Assets/Scripts`)
| File | Role |
|---|---|
| `Config.cs` | All tuning numbers, chip names, palette (mirrors web `config.js`) |
| `Bootstrap.cs` | Creates camera, audio and game at runtime from any scene |
| `BugBashGame.cs` | Gameplay: spawning, hit rules, scoring, health, fever, boss, game over |
| `BugBashGame.UI.cs` | Canvas, HUD, title / pause / game-over screens, buttons |
| `BugBashGame.FX.cs` | Backdrop, particles, floating text, screen shake, flashes |
| `AudioManager.cs` | Synthesised music + 15 sound effects, mute persistence |
| `SpriteFactory.cs` | Generates rounded-rect, circle, glow sprites |
| `InputHelper.cs` | Touch / mouse / keyboard for old and new Input System |
| `Editor/BugBashBuildTools.cs` | One-click Android setup + APK build |
