using UnityEngine;
using UnityEngine.UI;

namespace BugBash
{
    public partial class BugBashGame
    {
        class Particle { public RectTransform rt; public Image img; public Vector2 pos, vel; public float life, maxLife, size; public Color col; }
        class FloatTxt { public Text t; public float life; public Vector2 pos; }

        Particle[] parts; FloatTxt[] floats; int nextPart, nextFloat;
        Image bgImage, flashImage, buildLine;
        RectTransform[] codeLines; Text[] codeLineText;
        float shakeAmp, scroll, flashAlpha;
        Color flashCol;
        bool lite;
        const float LineH = 84f; const int LineCount = 40;

        void BuildBackground()
        {
            lite = SystemInfo.systemMemorySize <= 2048;
            bgImage = MakeImage(canvas.transform, SpriteFactory.White, Config.Bg);
            Stretch(bgImage.rectTransform);

            codeLines = new RectTransform[LineCount]; codeLineText = new Text[LineCount];
            for (int i = 0; i < LineCount; i++)
            {
                string src = Config.BackdropLines[i % Config.BackdropLines.Length];
                var t = MakeText(canvas.transform, (i + 1).ToString().PadLeft(3) + "   " + src, 34, new Color(0.55f, 0.6f, 0.68f, 0.22f),
                    TextAnchor.MiddleLeft, new Vector2(0.5f, 1f), Vector2.zero, new Vector2(960, LineH));
                codeLineText[i] = t; codeLines[i] = t.rectTransform;
            }
            var gutter = MakeImage(canvas.transform, SpriteFactory.White, new Color(1, 1, 1, 0.08f));
            gutter.rectTransform.anchorMin = new Vector2(0.5f, 0); gutter.rectTransform.anchorMax = new Vector2(0.5f, 1);
            gutter.rectTransform.sizeDelta = new Vector2(3, 0); gutter.rectTransform.anchoredPosition = new Vector2(-330, 0);

            // the "main" line at the bottom: bugs that cross it hurt
            buildLine = MakeImage(canvas.transform, SpriteFactory.White, new Color(Config.Red.r, Config.Red.g, Config.Red.b, 0.7f));
            buildLine.rectTransform.anchorMin = new Vector2(0, 0); buildLine.rectTransform.anchorMax = new Vector2(1, 0);
            buildLine.rectTransform.pivot = new Vector2(0.5f, 0.5f);
            buildLine.rectTransform.sizeDelta = new Vector2(0, 6);
            buildLine.rectTransform.anchoredPosition = new Vector2(0, Config.BottomLine);
            var mainLbl = MakeText(buildLine.transform, "main  -  don't let bugs reach this line", 30, new Color(1f, 0.6f, 0.6f, 0.9f),
                TextAnchor.LowerCenter, new Vector2(0.5f, 0f), new Vector2(0, -80), new Vector2(1000, 60));
            var lowerFill = MakeImage(canvas.transform, SpriteFactory.White, new Color(0.7f, 0.1f, 0.12f, 0.12f));
            lowerFill.rectTransform.anchorMin = new Vector2(0, 0); lowerFill.rectTransform.anchorMax = new Vector2(1, 0);
            lowerFill.rectTransform.pivot = new Vector2(0.5f, 0f);
            lowerFill.rectTransform.sizeDelta = new Vector2(0, Config.BottomLine); lowerFill.rectTransform.anchoredPosition = Vector2.zero;
        }

        void BuildFX()
        {
            int pc = lite ? 70 : 180;
            parts = new Particle[pc];
            for (int i = 0; i < pc; i++)
            {
                var im = MakeImage(playRect, lite ? SpriteFactory.Circle : SpriteFactory.Glow, Color.white);
                im.rectTransform.anchorMin = im.rectTransform.anchorMax = new Vector2(0.5f, 0.5f);
                im.gameObject.SetActive(false);
                parts[i] = new Particle { rt = im.rectTransform, img = im };
            }
            floats = new FloatTxt[14];
            for (int i = 0; i < floats.Length; i++)
            {
                var t = MakeText(playRect, "", 58, Color.white, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), Vector2.zero, new Vector2(900, 80), true);
                t.horizontalOverflow = HorizontalWrapMode.Overflow;
                var ol = t.gameObject.AddComponent<Outline>(); ol.effectColor = new Color(0, 0, 0, 0.8f); ol.effectDistance = new Vector2(3, -3);
                t.gameObject.SetActive(false);
                floats[i] = new FloatTxt { t = t };
            }
            flashImage = MakeImage(canvas.transform, SpriteFactory.White, new Color(1, 1, 1, 0));
            Stretch(flashImage.rectTransform);
        }

        void ClearFX()
        {
            if (parts == null) return;
            foreach (var p in parts) p.img.gameObject.SetActive(false);
            foreach (var f in floats) f.t.gameObject.SetActive(false);
            shakeAmp = 0f; flashAlpha = 0f;
        }

        // ---------------------------- effect requests ----------------------------
        public void FX_Burst(Vector2 pos, Color col, int count, float speed)
        {
            if (parts == null) return;
            if (lite) count = Mathf.Max(1, count / 2);
            col.a = 1f;
            for (int i = 0; i < count; i++)
            {
                var p = parts[nextPart]; nextPart = (nextPart + 1) % parts.Length;
                float ang = Random.value * Mathf.PI * 2f, sp = speed * Random.Range(0.3f, 1f);
                p.pos = pos; p.vel = new Vector2(Mathf.Cos(ang), Mathf.Sin(ang)) * sp;
                p.maxLife = p.life = Random.Range(0.4f, 0.9f);
                p.size = Random.Range(24f, lite ? 40f : 70f); p.col = col;
                p.img.gameObject.SetActive(true);
            }
        }

        public void FX_Float(Vector2 pos, string s, Color col)
        {
            if (floats == null) return;
            var f = floats[nextFloat]; nextFloat = (nextFloat + 1) % floats.Length;
            f.t.text = s; f.t.color = col; f.pos = pos; f.life = 1.0f;
            f.t.gameObject.SetActive(true);
        }

        public void FX_Shake(float amp) { shakeAmp = Mathf.Max(shakeAmp, amp); }
        public void FX_Flash(Color c, float a) { flashCol = c; flashAlpha = Mathf.Max(flashAlpha, a); }

        // ---------------------------- per-frame ----------------------------
        void UpdateFX(float dt)
        {
            if (playRect == null) return;
            if (parts != null)
            {
                foreach (var p in parts)
                {
                    if (!p.img.gameObject.activeSelf) continue;
                    p.life -= dt;
                    if (p.life <= 0f) { p.img.gameObject.SetActive(false); continue; }
                    p.vel.y -= 1100f * dt; p.pos += p.vel * dt;
                    float k = p.life / p.maxLife;
                    p.rt.anchoredPosition = p.pos;
                    p.rt.sizeDelta = Vector2.one * p.size * (0.4f + 0.6f * k);
                    var c = p.col; c.a = k; p.img.color = c;
                }
                foreach (var f in floats)
                {
                    if (!f.t.gameObject.activeSelf) continue;
                    f.life -= dt;
                    if (f.life <= 0f) { f.t.gameObject.SetActive(false); continue; }
                    f.pos.y += 130f * dt;
                    f.t.rectTransform.anchoredPosition = f.pos;
                    var c = f.t.color; c.a = Mathf.Clamp01(f.life * 2f); f.t.color = c;
                    f.t.rectTransform.localScale = Vector3.one * (1f + 0.25f * Mathf.Clamp01(f.life - 0.7f) * 3f);
                }
            }

            // screen shake only moves the playfield, never the HUD
            shakeAmp = Mathf.MoveTowards(shakeAmp, 0f, 70f * dt);
            playRect.anchoredPosition = shakeAmp > 0.1f ? new Vector2(Random.Range(-shakeAmp, shakeAmp), Random.Range(-shakeAmp, shakeAmp)) : Vector2.zero;

            flashAlpha = Mathf.MoveTowards(flashAlpha, 0f, 1.6f * dt);
            var fc = flashCol; fc.a = flashAlpha; flashImage.color = fc;

            // background tint: fever = gold pulse, slow = blue, otherwise GitHub dark
            Color target = Config.Bg;
            if (state == GState.Playing && fever) target = Color.Lerp(Config.Bg, new Color(0.22f, 0.16f, 0.02f), 0.5f + 0.5f * Mathf.Sin(Time.unscaledTime * 8f));
            else if (state == GState.Playing && slowTimer > 0f) target = new Color(0.04f, 0.10f, 0.20f);
            bgImage.color = Color.Lerp(bgImage.color, target, 10f * dt);

            // scrolling code backdrop: speeds up with the game, slows with the slow-time power-up
            float speed = state == GState.Playing ? Mathf.Lerp(70f, 200f, Mathf.Clamp01(elapsed / Config.RampSeconds)) * (slowTimer > 0f ? Config.SlowFactor : 1f) : 25f;
            if (state != GState.Paused && state != GState.GameOver) scroll += speed * dt;
            float total = LineH * LineCount;
            for (int i = 0; i < LineCount; i++)
                codeLines[i].anchoredPosition = new Vector2(30f, -(Mathf.Repeat(i * LineH + scroll, total)) + LineH);
            float pulse = 0.55f + 0.2f * Mathf.Sin(Time.unscaledTime * 4f);
            var bl = buildLine.color; bl.a = pulse; buildLine.color = bl;
        }
    }
}
