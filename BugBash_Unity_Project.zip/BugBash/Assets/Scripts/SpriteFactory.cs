using System;
using UnityEngine;

namespace BugBash
{
    /// <summary>Generates every sprite in code, so the game needs no imported art.</summary>
    public static class SpriteFactory
    {
        static bool init;
        public static Sprite White, Rounded, Circle, Glow;

        public static void Init()
        {
            if (init && White != null) return;
            init = true;
            White = Make(4, (x, y) => 1f, 0);
            Rounded = Make(64, (x, y) =>
            {
                float c = 32f, r = 20f;
                float qx = Mathf.Abs(x - c) - (c - r), qy = Mathf.Abs(y - c) - (c - r);
                float d = new Vector2(Mathf.Max(qx, 0), Mathf.Max(qy, 0)).magnitude + Mathf.Min(Mathf.Max(qx, qy), 0) - r;
                return Mathf.Clamp01(0.5f - d);
            }, 24);
            Circle = Make(64, (x, y) => Mathf.Clamp01(0.5f - (new Vector2(x - 32f, y - 32f).magnitude - 31f)), 0);
            Glow = Make(64, (x, y) => { float t = 1f - Mathf.Clamp01(new Vector2(x - 32f, y - 32f).magnitude / 32f); return t * t; }, 0);
        }

        static Sprite Make(int size, Func<float, float, float> alpha, float border)
        {
            var tex = new Texture2D(size, size, TextureFormat.RGBA32, false) { wrapMode = TextureWrapMode.Clamp, filterMode = FilterMode.Bilinear };
            var px = new Color[size * size];
            for (int y = 0; y < size; y++)
                for (int x = 0; x < size; x++)
                    px[y * size + x] = new Color(1, 1, 1, alpha(x + 0.5f, y + 0.5f));
            tex.SetPixels(px); tex.Apply();
            return Sprite.Create(tex, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f, 0, SpriteMeshType.FullRect, new Vector4(border, border, border, border));
        }
    }
}
