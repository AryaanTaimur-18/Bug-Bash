using UnityEngine;

namespace BugBash
{
    /// <summary>Builds the whole game at runtime, so any scene (even an empty one) can run it.</summary>
    public static class Bootstrap
    {
        [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
        static void Boot()
        {
            if (GameObject.Find("BugBash") != null) return;
            Application.targetFrameRate = 60;
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
            Screen.orientation = ScreenOrientation.Portrait;

            if (Camera.allCamerasCount == 0)
            {
                var camGo = new GameObject("Main Camera") { tag = "MainCamera" };
                camGo.AddComponent<Camera>(); camGo.AddComponent<AudioListener>();
            }
            var cam = Camera.main != null ? Camera.main : Camera.allCameras[0];
            cam.clearFlags = CameraClearFlags.SolidColor; cam.backgroundColor = Config.Bg;
            if (Object.FindFirstObjectByType<AudioListener>() == null) cam.gameObject.AddComponent<AudioListener>();

            var root = new GameObject("BugBash");
            root.AddComponent<AudioManager>();
            root.AddComponent<BugBashGame>();
        }
    }
}
