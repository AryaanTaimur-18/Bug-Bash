using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace BugBash
{
    public partial class BugBashGame
    {
        class Btn { public RectTransform rt; public Action act; }

        Canvas canvas; RectTransform canvasRect, playRect, hudRect;
        float topInset;
        float HudTotal { get { return Config.HudHeight + topInset; } }
        Text scoreText, bestText, multText, feverText;
        Image comboFill; Image[] healthFill = new Image[3];
        GameObject titlePanel, pausePanel, overPanel;
        Text titleBest, overTitle, overReasonText, overScore, overBest;
        readonly List<Btn> buttons = new List<Btn>();
        readonly List<Text> muteLabels = new List<Text>();
        int cScore = -1, cMult = -1, cBest = -1, cCombo = -1;
        static Font font;

        static Font GetFont()
        {
            if (font != null) return font;
            font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            if (font == null) font = Font.CreateDynamicFontFromOSFont("Arial", 32);
            return font;
        }

        // ---------------------------------- widgets ----------------------------------
        RectTransform MakeRect(string name, Transform parent)
        {
            var go = new GameObject(name, typeof(RectTransform));
            var rt = go.GetComponent<RectTransform>();
            rt.SetParent(parent, false);
            return rt;
        }

        Image MakeImage(Transform parent, Sprite spr, Color col)
        {
            var rt = MakeRect("img", parent);
            var im = rt.gameObject.AddComponent<Image>();
            im.sprite = spr; im.color = col; im.raycastTarget = false;
            return im;
        }

        void Stretch(RectTransform rt) { rt.anchorMin = Vector2.zero; rt.anchorMax = Vector2.one; rt.offsetMin = rt.offsetMax = Vector2.zero; }

        Text MakeText(Transform parent, string s, int size, Color col, TextAnchor align, Vector2 anchor, Vector2 pos, Vector2 sz, bool bold = false)
        {
            var rt = MakeRect("txt", parent);
            rt.anchorMin = rt.anchorMax = rt.pivot = anchor;
            rt.anchoredPosition = pos; rt.sizeDelta = sz;
            var t = rt.gameObject.AddComponent<Text>();
            t.font = GetFont(); t.text = s; t.fontSize = size; t.color = col; t.alignment = align;
            t.fontStyle = bold ? FontStyle.Bold : FontStyle.Normal;
            t.horizontalOverflow = HorizontalWrapMode.Wrap; t.verticalOverflow = VerticalWrapMode.Overflow;
            t.raycastTarget = false;
            return t;
        }

        Btn MakeButton(Transform parent, string label, Vector2 anchor, Vector2 pos, Vector2 sz, Color col, Action act, int fs = 56, Color? textCol = null)
        {
            var rt = MakeRect("btn_" + label, parent);
            rt.anchorMin = rt.anchorMax = rt.pivot = anchor;
            rt.anchoredPosition = pos; rt.sizeDelta = sz;
            var im = rt.gameObject.AddComponent<Image>();
            im.sprite = SpriteFactory.Rounded; im.type = Image.Type.Sliced; im.color = col; im.raycastTarget = false;
            var ol = rt.gameObject.AddComponent<Outline>(); ol.effectColor = new Color(0, 0, 0, 0.5f); ol.effectDistance = new Vector2(3, -3);
            var t = MakeText(rt, label, fs, textCol ?? Color.white, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), Vector2.zero, sz, true);
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            if (label.StartsWith("SOUND")) muteLabels.Add(t);
            var b = new Btn { rt = rt, act = act };
            buttons.Add(b);
            return b;
        }

        bool HandleButtons(Vector2 screenPos)
        {
            for (int i = buttons.Count - 1; i >= 0; i--)
            {
                var b = buttons[i];
                if (b.rt == null || !b.rt.gameObject.activeInHierarchy) continue;
                if (RectTransformUtility.RectangleContainsScreenPoint(b.rt, screenPos, null))
                {
                    AudioManager.I.Play(Snd.Click);
                    b.act();
                    return true;
                }
            }
            return false;
        }

        void ToggleMute() { AudioManager.I.ToggleMute(); UpdateMuteLabels(); }
        void UpdateMuteLabels() { foreach (var t in muteLabels) t.text = AudioManager.I.Muted ? "SOUND: OFF" : "SOUND: ON"; }

        // ---------------------------------- build ----------------------------------
        void BuildCanvas()
        {
            var go = new GameObject("BugBashCanvas");
            go.transform.SetParent(transform, false);
            canvas = go.AddComponent<Canvas>();
            canvas.renderMode = RenderMode.ScreenSpaceOverlay;
            var sc = go.AddComponent<CanvasScaler>();
            sc.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            sc.referenceResolution = new Vector2(Config.RefWidth, 1920f);
            sc.screenMatchMode = CanvasScaler.ScreenMatchMode.MatchWidthOrHeight;
            sc.matchWidthOrHeight = 0f;     // keep width = 1080, height follows the phone's aspect ratio
            canvasRect = go.GetComponent<RectTransform>();
            Rect sa = Screen.safeArea;
            topInset = Mathf.Max(0f, (Screen.height - sa.yMax) / Screen.height) * (Screen.height * (Config.RefWidth / Screen.width));
        }

        void BuildPlayfield()
        {
            playRect = MakeRect("Playfield", canvas.transform);
            playRect.anchorMin = playRect.anchorMax = playRect.pivot = new Vector2(0.5f, 0.5f);
            playRect.sizeDelta = Vector2.zero;
        }

        void BuildHud()
        {
            hudRect = MakeRect("HUD", canvas.transform);
            hudRect.anchorMin = new Vector2(0, 1); hudRect.anchorMax = new Vector2(1, 1); hudRect.pivot = new Vector2(0.5f, 1);
            hudRect.sizeDelta = new Vector2(0, HudTotal); hudRect.anchoredPosition = Vector2.zero;
            var bar = hudRect.gameObject.AddComponent<Image>();
            bar.color = new Color(0.086f, 0.106f, 0.133f, 0.97f); bar.raycastTarget = false;
            var line = MakeImage(hudRect, SpriteFactory.White, Config.Border);
            line.rectTransform.anchorMin = new Vector2(0, 0); line.rectTransform.anchorMax = new Vector2(1, 0);
            line.rectTransform.sizeDelta = new Vector2(0, 4);

            float top = -(topInset + 20f);
            scoreText = MakeText(hudRect, "0", 80, Color.white, TextAnchor.UpperLeft, new Vector2(0, 1), new Vector2(40, top), new Vector2(480, 100), true);
            bestText = MakeText(hudRect, "BEST 0", 36, Config.Text, TextAnchor.UpperLeft, new Vector2(0, 1), new Vector2(40, top - 100), new Vector2(480, 50));
            multText = MakeText(hudRect, "x1", 84, Config.Gold, TextAnchor.UpperCenter, new Vector2(0.5f, 1), new Vector2(0, top), new Vector2(300, 100), true);
            var cb = MakeImage(hudRect, SpriteFactory.White, new Color(1, 1, 1, 0.12f));
            SetTop(cb.rectTransform, new Vector2(0.5f, 1), new Vector2(0, top - 115), new Vector2(220, 14));
            comboFill = MakeImage(hudRect, SpriteFactory.White, Config.Gold);
            SetTop(comboFill.rectTransform, new Vector2(0.5f, 1), new Vector2(0, top - 115), new Vector2(220, 14));
            comboFill.rectTransform.pivot = new Vector2(0.5f, 1);
            comboFill.type = Image.Type.Filled; comboFill.fillMethod = Image.FillMethod.Horizontal;
            feverText = MakeText(hudRect, "", 34, Config.Gold, TextAnchor.UpperCenter, new Vector2(0.5f, 1), new Vector2(0, top - 140), new Vector2(500, 50), true);

            for (int i = 0; i < 3; i++)
            {
                var back = MakeImage(hudRect, SpriteFactory.White, new Color(1, 1, 1, 0.12f));
                SetTop(back.rectTransform, new Vector2(1, 1), new Vector2(-40 - i * 100, top - 4), new Vector2(86, 26));
                healthFill[i] = MakeImage(hudRect, SpriteFactory.White, Config.Green);
                SetTop(healthFill[i].rectTransform, new Vector2(1, 1), new Vector2(-40 - i * 100, top - 4), new Vector2(86, 26));
                healthFill[i].type = Image.Type.Filled; healthFill[i].fillMethod = Image.FillMethod.Horizontal; healthFill[i].fillOrigin = 1;
            }
            MakeText(hudRect, "BUILD", 28, Config.Text, TextAnchor.UpperRight, new Vector2(1, 1), new Vector2(-40, top - 36), new Vector2(300, 40));
            MakeButton(hudRect, "II", new Vector2(1, 1), new Vector2(-40, top - 90), new Vector2(110, 80), Config.Border, () => { if (state == GState.Playing) SetState(GState.Paused); }, 44);
            MakeButton(hudRect, "M", new Vector2(1, 1), new Vector2(-170, top - 90), new Vector2(110, 80), Config.Border, ToggleMute, 44);
        }

        void SetTop(RectTransform rt, Vector2 anchor, Vector2 pos, Vector2 sz)
        { rt.anchorMin = rt.anchorMax = rt.pivot = anchor; rt.anchoredPosition = pos; rt.sizeDelta = sz; }

        GameObject MakePanel(string name, float alpha)
        {
            var rt = MakeRect(name, canvas.transform);
            Stretch(rt);
            var im = rt.gameObject.AddComponent<Image>();
            im.color = new Color(0.05f, 0.07f, 0.09f, alpha); im.raycastTarget = false;
            return rt.gameObject;
        }

        void BuildPanels()
        {
            Vector2 mid = new Vector2(0.5f, 0.5f);
            // ---------- title ----------
            titlePanel = MakePanel("Title", 0.93f);
            var tp = titlePanel.transform;
            MakeText(tp, "BUG BASH", 150, Config.Green, TextAnchor.MiddleCenter, mid, new Vector2(0, 520), new Vector2(1000, 180), true);
            MakeText(tp, "DON'T TOUCH edition  -  keep the build green", 40, Config.Text, TextAnchor.MiddleCenter, mid, new Vector2(0, 400), new Vector2(1000, 60));
            MakeText(tp,
                "Tap or swipe the <color=#f85149>red bugs</color> to squash them.\n\n" +
                "<b>DON'T TOUCH</b> working code, features, or the <color=#d29922>(!) git push --force</color> command.\n\n" +
                "3 squashes in a row raise your multiplier.\nReach x5 for FEVER: double points!\n\n" +
                "Power-ups heal, slow time or fix every bug.\nBosses appear after 40 seconds.",
                38, Config.Text, TextAnchor.MiddleCenter, mid, new Vector2(0, 90), new Vector2(940, 560)).supportRichText = true;
            titleBest = MakeText(tp, "BEST 0", 50, Config.Gold, TextAnchor.MiddleCenter, mid, new Vector2(0, -280), new Vector2(800, 70), true);
            MakeButton(tp, "PLAY", mid, new Vector2(0, -430), new Vector2(560, 150), Config.Green, StartGame, 76);
            MakeButton(tp, "SOUND: ON", mid, new Vector2(0, -620), new Vector2(460, 100), Config.Border, ToggleMute, 40);

            // ---------- pause ----------
            pausePanel = MakePanel("Pause", 0.85f);
            var pp = pausePanel.transform;
            MakeText(pp, "PAUSED", 120, Color.white, TextAnchor.MiddleCenter, mid, new Vector2(0, 330), new Vector2(900, 150), true);
            MakeButton(pp, "RESUME", mid, new Vector2(0, 100), new Vector2(520, 140), Config.Green, () => SetState(GState.Playing), 64);
            MakeButton(pp, "RESTART", mid, new Vector2(0, -80), new Vector2(520, 120), Config.Blue, StartGame, 52);
            MakeButton(pp, "SOUND: ON", mid, new Vector2(0, -230), new Vector2(520, 100), Config.Border, ToggleMute, 40);
            MakeButton(pp, "MENU", mid, new Vector2(0, -370), new Vector2(520, 100), Config.Border, () => SetState(GState.Title), 44);

            // ---------- game over ----------
            overPanel = MakePanel("GameOver", 0.9f);
            var op = overPanel.transform;
            overTitle = MakeText(op, "BUILD FAILED", 120, Config.Red, TextAnchor.MiddleCenter, mid, new Vector2(0, 400), new Vector2(1000, 150), true);
            overReasonText = MakeText(op, "", 44, Config.Text, TextAnchor.MiddleCenter, mid, new Vector2(0, 270), new Vector2(940, 120));
            overScore = MakeText(op, "0", 150, Color.white, TextAnchor.MiddleCenter, mid, new Vector2(0, 100), new Vector2(900, 180), true);
            overBest = MakeText(op, "", 50, Config.Gold, TextAnchor.MiddleCenter, mid, new Vector2(0, -50), new Vector2(900, 80), true);
            MakeButton(op, "TRY AGAIN", mid, new Vector2(0, -230), new Vector2(560, 150), Config.Green, StartGame, 62);
            MakeButton(op, "MENU", mid, new Vector2(0, -410), new Vector2(560, 110), Config.Border, () => SetState(GState.Title), 48);
            UpdateMuteLabels();
        }

        void ShowPanels()
        {
            if (titlePanel == null) return;
            titlePanel.SetActive(state == GState.Title);
            pausePanel.SetActive(state == GState.Paused);
            overPanel.SetActive(state == GState.GameOver);
            hudRect.gameObject.SetActive(state != GState.Title);
            if (state == GState.Title) titleBest.text = "BEST " + best;
            if (state == GState.GameOver)
            {
                overReasonText.text = overReason;
                overScore.text = score.ToString();
                overBest.text = newBest ? "NEW BEST!" : "BEST " + best;
                overTitle.text = overReason.Contains("force") ? "MAIN IS GONE" : "BUILD FAILED";
            }
            UpdateMuteLabels();
        }

        void RefreshHud()
        {
            if (hudRect == null || !hudRect.gameObject.activeSelf) return;
            if (cScore != score) { cScore = score; scoreText.text = score.ToString(); }
            if (cBest != best) { cBest = best; bestText.text = "BEST " + best; }
            int shownMult = Multiplier();
            if (cMult != shownMult) { cMult = shownMult; multText.text = "x" + shownMult; }
            comboFill.fillAmount = fever ? Mathf.Clamp01(feverTimer / Config.FeverSeconds) : (mult >= Config.MaxMultiplier ? 1f : (combo % Config.StreakPerMultiplier) / (float)Config.StreakPerMultiplier);
            feverText.text = fever ? "FEVER " + feverTimer.ToString("0.0") + "s" : (slowTimer > 0f ? "SLOW " + slowTimer.ToString("0.0") + "s" : "");
            for (int i = 0; i < 3; i++)
            {
                float f = Mathf.Clamp01(health - i);
                healthFill[i].fillAmount = f;
                healthFill[i].color = health <= 1.01f ? Config.Red : (health <= 2.01f ? Config.Yellow : Config.Green);
            }
        }
    }
}
