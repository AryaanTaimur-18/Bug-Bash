using System;
using System.Collections.Generic;
using UnityEngine;

namespace BugBash
{
    public enum Snd { Click, Start, Squash, BossHit, Combo, Hurt, Explosion, ForcePush, PowerUp, Heal, Slow, Fever, BossSpawn, Jump, GameOver }

    /// <summary>
    /// Every sound is synthesised in code (no audio files needed): chiptune background music,
    /// squash / jump / explosion / power-up / game-over effects. Mute is saved in PlayerPrefs.
    /// </summary>
    public class AudioManager : MonoBehaviour
    {
        public static AudioManager I;
        const int SR = 22050;
        const float TwoPi = 6.2831853f;

        AudioSource music;
        AudioSource[] pool;
        int next;
        readonly Dictionary<Snd, AudioClip> clips = new Dictionary<Snd, AudioClip>();
        public bool Muted { get; private set; }

        void Awake()
        {
            I = this;
            Muted = PlayerPrefs.GetInt("bb_mute", 0) == 1;
            music = gameObject.AddComponent<AudioSource>();
            music.loop = true; music.volume = 0.45f; music.playOnAwake = false;
            pool = new AudioSource[10];
            for (int i = 0; i < pool.Length; i++) { pool[i] = gameObject.AddComponent<AudioSource>(); pool[i].playOnAwake = false; }
            Build();
            music.clip = BuildMusic();
            ApplyMute();
            music.Play();
        }

        public void SetMuted(bool m) { Muted = m; PlayerPrefs.SetInt("bb_mute", m ? 1 : 0); PlayerPrefs.Save(); ApplyMute(); }
        public void ToggleMute() { SetMuted(!Muted); }
        void ApplyMute() { music.mute = Muted; foreach (var s in pool) s.mute = Muted; }
        public void SetMusicPitch(float p) { music.pitch = p; }
        public void SetMusicVolume(float v) { music.volume = v; }

        public void Play(Snd id, float vol = 1f, float pitchVar = 0.06f)
        {
            AudioClip c;
            if (Muted || !clips.TryGetValue(id, out c)) return;
            var s = pool[next]; next = (next + 1) % pool.Length;
            s.pitch = 1f + UnityEngine.Random.Range(-pitchVar, pitchVar);
            s.volume = vol;
            s.clip = c; s.Play();
        }

        // ---------------- synthesis helpers ----------------
        static float Sin(float f, float t) { return Mathf.Sin(TwoPi * f * t); }
        static float Sq(float f, float t, float duty = 0.5f) { return Mathf.Repeat(f * t, 1f) < duty ? 1f : -1f; }
        static float Saw(float f, float t) { return Mathf.Repeat(f * t, 1f) * 2f - 1f; }
        static float Tri(float f, float t) { return Mathf.Abs(Mathf.Repeat(f * t, 1f) * 4f - 2f) - 1f; }
        static float Noise(float t) { return Mathf.Repeat(Mathf.Sin(Mathf.Floor(t * SR) * 12.9898f) * 43758.5453f, 1f) * 2f - 1f; }
        static float Note(float semi) { return 440f * Mathf.Pow(2f, semi / 12f); }
        /// <summary>Phase (in cycles) of an exponential frequency sweep f0 -> f1 over d seconds.</summary>
        static float Sweep(float f0, float f1, float d, float t)
        {
            float k = Mathf.Log(f1 / f0);
            return f0 * d / k * (Mathf.Exp(k * t / d) - 1f);
        }
        static float Dec(float t, float k) { return Mathf.Exp(-t * k); }

        static AudioClip Make(string name, float dur, Func<float, float> gen)
        {
            int n = Mathf.CeilToInt(dur * SR);
            var data = new float[n];
            for (int i = 0; i < n; i++)
            {
                float t = i / (float)SR;
                float v = gen(t);
                float fade = Mathf.Clamp01((dur - t) * 40f);       // avoid clicks at the end
                data[i] = Mathf.Clamp(v * fade, -1f, 1f);
            }
            var c = AudioClip.Create(name, n, 1, SR, false);
            c.SetData(data, 0);
            return c;
        }

        static Func<float, float> Arp(float[] semis, float step, float duty, float decay, float amp)
        {
            return t =>
            {
                int i = Mathf.Min(semis.Length - 1, (int)(t / step));
                float lt = t - i * step;
                return Sq(Note(semis[i]), t, duty) * Dec(lt, decay) * amp;
            };
        }

        static Func<float, float> Boom(float dur, float low)
        {
            float lp = 0f;     // one-pole low-pass state (samples are generated in order)
            return t =>
            {
                float a = Mathf.Lerp(0.5f, 0.03f, Mathf.Clamp01(t / dur));
                lp += a * (Noise(t) - lp);
                return lp * 3.2f * Dec(t, 3.5f) + Sin(Mathf.Lerp(low, low * 0.4f, t / dur), t) * Dec(t, 5f) * 0.9f;
            };
        }

        void Build()
        {
            clips[Snd.Click] = Make("click", 0.05f, t => Sin(1000f, t) * Dec(t, 60f) * 0.5f);
            clips[Snd.Start] = Make("start", 0.4f, Arp(new float[] { 0, 7, 12, 19 }, 0.1f, 0.25f, 10f, 0.35f));
            clips[Snd.Squash] = Make("squash", 0.18f, t =>
                Mathf.Sin(TwoPi * Sweep(700f, 140f, 0.18f, t)) * Dec(t, 16f) * 0.8f + Noise(t) * Dec(t, 60f) * 0.5f);
            clips[Snd.BossHit] = Make("bosshit", 0.14f, t => Sq(160f, t) * Dec(t, 28f) * 0.5f + Noise(t) * Dec(t, 50f) * 0.4f);
            clips[Snd.Combo] = Make("combo", 0.32f, Arp(new float[] { 5, 9, 12, 17 }, 0.075f, 0.5f, 14f, 0.4f));
            clips[Snd.Hurt] = Make("hurt", 0.5f, t => (Mathf.Repeat(Sweep(220f, 70f, 0.5f, t), 1f) * 2f - 1f) * Dec(t, 4f) * 0.6f);
            clips[Snd.Explosion] = Make("explosion", 1.0f, Boom(1.0f, 70f));
            clips[Snd.ForcePush] = Make("forcepush", 1.6f, Boom(1.6f, 50f));
            clips[Snd.PowerUp] = Make("powerup", 0.5f, Arp(new float[] { 0, 4, 7, 12, 16 }, 0.09f, 0.25f, 9f, 0.4f));
            clips[Snd.Heal] = Make("heal", 0.4f, t => { float lt = t % 0.2f; return Sin(Note(t < 0.2f ? 12 : 19), t) * Dec(lt, 8f) * 0.5f; });
            clips[Snd.Slow] = Make("slow", 0.7f, t =>
                Sin(Mathf.Lerp(900f, 150f, t / 0.7f) * (1f + 0.03f * Mathf.Sin(t * 50f)), t) * Dec(t, 2.2f) * 0.5f);
            clips[Snd.Fever] = Make("fever", 0.7f, t =>
                Mathf.Sign(Mathf.Sin(TwoPi * Sweep(300f, 1400f, 0.7f, t))) * 0.3f * Mathf.Min(1f, (0.7f - t) * 8f));
            clips[Snd.BossSpawn] = Make("bossspawn", 1.2f, t =>
            {
                float lt = t % 0.4f;
                return (Saw(60f, t) * 0.5f + Sin(45f, t) * 0.5f) * Dec(lt, 5f) * 0.9f;
            });
            clips[Snd.Jump] = Make("jump", 0.3f, t =>
            {
                float ph = t < 0.14f ? Sweep(250f, 750f, 0.14f, t) : Sweep(250f, 750f, 0.14f, 0.14f) + Sweep(750f, 300f, 0.14f, t - 0.14f);
                return Mathf.Sin(TwoPi * ph) * Dec(t, 6f) * 0.6f;
            });
            clips[Snd.GameOver] = Make("gameover", 1.5f, t =>
            {
                float[] n = { 7, 3, 0, -5, -12 };
                int i = Mathf.Min(n.Length - 1, (int)(t / 0.3f));
                float lt = t - i * 0.3f;
                return Tri(Note(n[i] - 12f), t) * Dec(lt, 2.5f) * 0.7f;
            });
        }

        // ---------------- background music: 132 BPM chiptune, Am - F - C - G ----------------
        static AudioClip BuildMusic()
        {
            const float bpm = 132f;
            float stepDur = 60f / bpm / 4f;
            float[] roots = { 0f, -4f, -9f, -2f };
            int[][] ints = { new[] { 0, 3, 7 }, new[] { 0, 4, 7 }, new[] { 0, 4, 7 }, new[] { 0, 4, 7 } };
            int[] lead = { 0, -1, 2, -1, 1, -1, 2, -1, 0, -1, 1, -1, 2, -1, 1, -1 };
            float total = stepDur * 64f;

            return Make("music", total, t =>
            {
                int step = (int)(t / stepDur);
                float lt = t - step * stepDur;
                int bar = (step / 16) % 4, s16 = step % 16;
                float root = roots[bar]; int[] ch = ints[bar];
                float v = 0f;
                if (s16 % 2 == 0) v += Tri(Note(root - 12f + (s16 % 4 == 2 ? 12f : 0f)), t) * Dec(lt, 6f) * 0.35f;       // bass
                v += Sq(Note(root + ch[s16 % 3]), t, 0.25f) * Dec(lt, 14f) * 0.10f;                                       // arpeggio
                int li = lead[s16];
                if (li >= 0) v += Sq(Note(root + ch[li] + 12f), t, 0.5f) * Dec(lt, 4f) * 0.10f;                           // lead
                if (s16 % 4 == 0 && lt < 0.12f) v += Mathf.Sin(TwoPi * Sweep(140f, 40f, 0.12f, lt)) * Dec(lt, 22f) * 0.6f; // kick
                if (s16 == 4 || s16 == 12) v += Noise(t) * Dec(lt, 18f) * 0.25f;                                          // snare
                if (s16 % 2 == 1) v += Noise(t) * Dec(lt, 60f) * 0.12f;                                                   // hat
                return v * 0.8f;
            });
        }
    }
}
