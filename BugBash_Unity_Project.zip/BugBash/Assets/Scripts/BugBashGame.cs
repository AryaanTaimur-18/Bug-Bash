using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace BugBash
{
    /// <summary>
    /// Bug Bash - DON'T TOUCH edition. Squash bugs, spare working code and features,
    /// never run "git push --force". Core gameplay; UI lives in BugBashGame.UI.cs, effects in BugBashGame.FX.cs.
    /// </summary>
    public partial class BugBashGame : MonoBehaviour
    {
        enum GState { Title, Playing, Paused, GameOver }

        class Chip
        {
            public ChipKind kind;
            public RectTransform rt;
            public Image bg;
            public Text label;
            public Image hpBar;
            public float x, y, w, h, speed, vx, vy, cool, flash, age;
            public int hp, maxHp;
            public string baseName;
            public bool dead;
        }

        GState state = GState.Title;
        float W = Config.RefWidth, H = 1920f;
        float elapsed, spawnTimer, nextBossAt, slowTimer, feverTimer, health;
        int score, best, combo, mult;
        bool fever, bossAlive, newBest;
        string overReason = "";
        readonly List<Chip> chips = new List<Chip>();
        Vector2 lastPtr; bool trackingSwipe;

        void Start()
        {
            SpriteFactory.Init();
            best = PlayerPrefs.GetInt("bb_best", 0);
            BuildCanvas();
            BuildBackground();
            BuildPlayfield();
            BuildFX();
            BuildHud();
            BuildPanels();
            SetState(GState.Title);
        }

        // ============================ main loop ============================
        void Update()
        {
            H = canvasRect.rect.height; W = canvasRect.rect.width;
            float rawDt = Mathf.Min(Time.unscaledDeltaTime, 0.05f);

            HandleKeys();
            var p = InputHelper.Pointer();
            bool uiConsumed = p.down && HandleButtons(p.pos);

            if (state == GState.Playing)
            {
                float dt = rawDt * (slowTimer > 0f ? Config.SlowFactor : 1f);
                TickGame(dt, rawDt);
                if (state == GState.Playing && !uiConsumed) HandleSwipe(p);
            }
            if (!p.held) trackingSwipe = false;

            chips.RemoveAll(c => c.dead);
            UpdateFX(rawDt);
            RefreshHud();
        }

        void OnApplicationPause(bool paused) { if (paused && state == GState.Playing) SetState(GState.Paused); }
        void OnApplicationFocus(bool focus) { if (!focus && state == GState.Playing) SetState(GState.Paused); }

        void HandleKeys()
        {
            if (InputHelper.KeyDown(GameKey.Mute)) ToggleMute();
            if (InputHelper.KeyDown(GameKey.Start))
            {
                if (state == GState.Playing) SetState(GState.Paused);
                else if (state == GState.Paused) SetState(GState.Playing);
                else StartGame();
            }
            if (InputHelper.KeyDown(GameKey.Reset) && state != GState.Title) StartGame();
            if (InputHelper.KeyDown(GameKey.Back))
            {
                if (state == GState.Playing) SetState(GState.Paused);
                else if (state == GState.Paused) SetState(GState.Playing);
            }
        }

        void SetState(GState s)
        {
            state = s;
            ShowPanels();
            var a = AudioManager.I;
            if (a != null)
            {
                a.SetMusicVolume(s == GState.Playing ? 0.45f : 0.3f);
                a.SetMusicPitch(s == GState.GameOver ? 0.7f : (fever ? 1.1f : 1f));
            }
        }

        public void StartGame()
        {
            foreach (var c in chips) if (c.rt != null) Destroy(c.rt.gameObject);
            chips.Clear();
            ClearFX();
            score = 0; health = Config.MaxHealth; combo = 0; mult = 1;
            elapsed = 0f; spawnTimer = 0.6f; nextBossAt = Config.FirstBossAt;
            slowTimer = 0f; feverTimer = 0f; fever = false; bossAlive = false; newBest = false;
            trackingSwipe = false;
            AudioManager.I.Play(Snd.Start);
            SetState(GState.Playing);
        }

        // ============================ simulation ============================
        void TickGame(float dt, float rawDt)
        {
            elapsed += rawDt;
            if (slowTimer > 0f) slowTimer -= rawDt;
            if (fever)
            {
                feverTimer -= rawDt;
                if (feverTimer <= 0f) EndFever(true);
            }

            float p = Mathf.Clamp01(elapsed / Config.RampSeconds);
            float baseSpeed = Mathf.Lerp(Config.FallSpeedStart, Config.FallSpeedEnd, p);

            spawnTimer -= dt;
            if (spawnTimer <= 0f)
            {
                SpawnOne(baseSpeed);
                spawnTimer = Mathf.Lerp(Config.SpawnIntervalStart, Config.SpawnIntervalEnd, p) * Random.Range(0.8f, 1.2f);
            }
            if (!bossAlive && elapsed >= nextBossAt) { SpawnBoss(baseSpeed); nextBossAt = elapsed + Config.BossEvery; }

            float floor = -H * 0.5f + Config.BottomLine;
            int n = chips.Count;
            for (int i = 0; i < n; i++)
            {
                var c = chips[i];
                if (c.dead) continue;
                c.age += dt;
                if (c.cool > 0f) c.cool -= rawDt;
                c.vx = Mathf.MoveTowards(c.vx, 0f, 700f * dt);
                c.vy = Mathf.MoveTowards(c.vy, 0f, 1500f * dt);
                c.x = Mathf.Clamp(c.x + c.vx * dt, -W * 0.5f + c.w * 0.5f + 10f, W * 0.5f - c.w * 0.5f - 10f);
                c.y += (c.vy - c.speed) * dt;
                if (c.flash > 0f) c.flash -= rawDt;
                float wob = Mathf.Sin(c.age * 6f + c.x) * (IsBugKind(c.kind) ? 2.5f : 0f);
                c.rt.anchoredPosition = new Vector2(c.x, c.y);
                c.rt.localRotation = Quaternion.Euler(0, 0, wob);
                c.bg.color = c.flash > 0f ? Color.white : BaseColor(c.kind);

                if (c.y - c.h * 0.5f < floor) { Escape(c); if (state != GState.Playing) return; }
            }
        }

        static bool IsBugKind(ChipKind k)
        { return k == ChipKind.Bug || k == ChipKind.BigBug || k == ChipKind.Splitter || k == ChipKind.SplitChild || k == ChipKind.Disguised || k == ChipKind.Boss; }

        void Escape(Chip c)
        {
            Vector2 pos = new Vector2(c.x, -H * 0.5f + Config.BottomLine);
            if (c.kind == ChipKind.Boss)
            {
                bossAlive = false; RemoveChip(c);
                Penalty(1f, "legacy_monolith.js survived");
            }
            else if (IsBugKind(c.kind))
            {
                RemoveChip(c);
                FX_Burst(pos, Config.Red, 8, 260f);
                Penalty(c.kind == ChipKind.SplitChild ? Config.SplitChildPenalty : 1f, "A bug reached main");
            }
            else RemoveChip(c);     // working code, features, power-ups and ⚠ commands may pass safely
        }

        // ============================ spawning ============================
        bool ForceOnScreen() { foreach (var c in chips) if (!c.dead && c.kind == ChipKind.Force) return true; return false; }

        void SpawnOne(float baseSpeed)
        {
            float el = elapsed;
            float wBug = 40f, wBig = el > 15f ? 9f : 0f, wSplit = el > 10f ? 9f : 0f, wDis = el > 20f ? 10f : 0f,
                  wCode = 18f, wFeat = 10f, wForce = (el > 8f && !ForceOnScreen()) ? 3f : 0f, wPower = 4f;
            float sum = wBug + wBig + wSplit + wDis + wCode + wFeat + wForce + wPower;
            float r = Random.value * sum;
            ChipKind k;
            if ((r -= wBug) < 0f) k = ChipKind.Bug;
            else if ((r -= wBig) < 0f) k = ChipKind.BigBug;
            else if ((r -= wSplit) < 0f) k = ChipKind.Splitter;
            else if ((r -= wDis) < 0f) k = ChipKind.Disguised;
            else if ((r -= wCode) < 0f) k = ChipKind.Code;
            else if ((r -= wFeat) < 0f) k = ChipKind.Feature;
            else if ((r -= wForce) < 0f) k = ChipKind.Force;
            else
            {
                float q = Random.value;
                if (health < Config.MaxHealth - 0.01f && q < 0.4f) k = ChipKind.Heal;
                else k = q < 0.7f ? ChipKind.Slow : ChipKind.FixAll;
            }
            float speed = baseSpeed * Random.Range(0.85f, 1.15f);
            Vector2 size = SizeOf(k);
            float x = 0f; bool ok = false;
            for (int t = 0; t < 6 && !ok; t++)
            {
                x = Random.Range(-W * 0.5f + size.x * 0.5f + 20f, W * 0.5f - size.x * 0.5f - 20f);
                ok = true;
                foreach (var c in chips)
                    if (!c.dead && c.y > H * 0.5f - 400f && Mathf.Abs(c.x - x) < (c.w + size.x) * 0.5f) { ok = false; break; }
            }
            CreateChip(k, x, H * 0.5f + size.y, speed);
        }

        void SpawnBoss(float baseSpeed)
        {
            bossAlive = true;
            CreateChip(ChipKind.Boss, 0f, H * 0.5f + 150f, baseSpeed * 0.3f);
            AudioManager.I.Play(Snd.BossSpawn);
            FX_Shake(18f);
            FX_Flash(Config.Purple, 0.35f);
            FX_Float(new Vector2(0, H * 0.5f - Config.HudHeight - 200f), "BOSS INCOMING!", Config.Purple);
        }

        static Vector2 SizeOf(ChipKind k)
        {
            switch (k)
            {
                case ChipKind.Bug: return new Vector2(320, 100);
                case ChipKind.BigBug: return new Vector2(440, 150);
                case ChipKind.Splitter: return new Vector2(350, 110);
                case ChipKind.SplitChild: return new Vector2(220, 80);
                case ChipKind.Disguised: return new Vector2(380, 100);
                case ChipKind.Code: return new Vector2(380, 100);
                case ChipKind.Feature: return new Vector2(470, 100);
                case ChipKind.Force: return new Vector2(580, 110);
                case ChipKind.Boss: return new Vector2(780, 230);
                default: return new Vector2(230, 110);
            }
        }

        static Color BaseColor(ChipKind k)
        {
            switch (k)
            {
                case ChipKind.Bug: return new Color(0.80f, 0.20f, 0.25f);
                case ChipKind.BigBug: return new Color(0.62f, 0.12f, 0.18f);
                case ChipKind.Splitter: return new Color(0.78f, 0.34f, 0.12f);
                case ChipKind.SplitChild: return new Color(0.9f, 0.45f, 0.15f);
                case ChipKind.Disguised: case ChipKind.Code: return new Color(0.09f, 0.14f, 0.20f);
                case ChipKind.Feature: return new Color(0.10f, 0.28f, 0.50f);
                case ChipKind.Force: return new Color(0.85f, 0.65f, 0.05f);
                case ChipKind.Heal: return new Color(0.15f, 0.60f, 0.25f);
                case ChipKind.Slow: return new Color(0.20f, 0.45f, 0.85f);
                case ChipKind.FixAll: return new Color(0.85f, 0.70f, 0.20f);
                default: return new Color(0.42f, 0.25f, 0.72f);       // Boss
            }
        }

        static T Pick<T>(T[] a) { return a[Random.Range(0, a.Length)]; }

        Chip CreateChip(ChipKind k, float x, float y, float speed)
        {
            Vector2 sz = SizeOf(k);
            var c = new Chip { kind = k, x = x, y = y, w = sz.x, h = sz.y, speed = speed, hp = 1 };
            if (k == ChipKind.BigBug) c.hp = Config.BigBugHp;
            if (k == ChipKind.Boss) c.hp = Config.BossHp;
            c.maxHp = c.hp;

            var go = new GameObject("chip_" + k, typeof(RectTransform));
            c.rt = go.GetComponent<RectTransform>();
            c.rt.SetParent(playRect, false);
            c.rt.anchorMin = c.rt.anchorMax = new Vector2(0.5f, 0.5f);
            c.rt.sizeDelta = sz;
            c.rt.anchoredPosition = new Vector2(x, y);
            c.bg = go.AddComponent<Image>();
            c.bg.sprite = SpriteFactory.Rounded; c.bg.type = Image.Type.Sliced; c.bg.color = BaseColor(k);
            var ol = go.AddComponent<Outline>(); ol.effectDistance = new Vector2(3, -3); ol.effectColor = OutlineColor(k);

            string txt; Color tc = Color.white; int fs = 40;
            switch (k)
            {
                case ChipKind.Bug: txt = Pick(Config.BugNames); break;
                case ChipKind.BigBug: txt = Pick(Config.BigBugNames); fs = 48; break;
                case ChipKind.Splitter: txt = Config.SplitName; break;
                case ChipKind.SplitChild: txt = "bug"; fs = 36; break;
                case ChipKind.Disguised: txt = Pick(Config.CodeNames); tc = Config.Green; fs = 34; break;
                case ChipKind.Code: txt = Pick(Config.CodeNames); tc = Config.Green; fs = 34; break;
                case ChipKind.Feature: txt = Pick(Config.FeatureNames); fs = 38; break;
                case ChipKind.Force: txt = Config.ForceName; tc = Color.black; fs = 42; break;
                case ChipKind.Heal: txt = "+ HEAL"; fs = 38; break;
                case ChipKind.Slow: txt = "SLOW"; fs = 40; break;
                case ChipKind.FixAll: txt = "FIX ALL"; fs = 38; tc = Color.black; break;
                default: txt = Config.BossName; fs = 60; break;
            }
            c.baseName = txt;
            c.label = MakeText(c.rt, txt, fs, tc, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), Vector2.zero, sz, true);
            c.label.horizontalOverflow = HorizontalWrapMode.Overflow;

            if (k == ChipKind.Disguised)   // looks like code, but with a wavy red underline
                MakeText(c.rt, "~~~~~~~~~~~~~", 30, Config.Red, TextAnchor.MiddleCenter, new Vector2(0.5f, 0.5f), new Vector2(0, -26), new Vector2(sz.x, 40), true);

            if (c.maxHp > 1)
            {
                var bar = MakeImage(c.rt, SpriteFactory.White, new Color(1, 1, 1, 0.85f));
                bar.rectTransform.anchorMin = new Vector2(0.05f, 0f); bar.rectTransform.anchorMax = new Vector2(0.95f, 0f);
                bar.rectTransform.pivot = new Vector2(0.5f, 0f);
                bar.rectTransform.sizeDelta = new Vector2(0, 12); bar.rectTransform.anchoredPosition = new Vector2(0, 10);
                bar.type = Image.Type.Filled; bar.fillMethod = Image.FillMethod.Horizontal; bar.fillAmount = 1f;
                c.hpBar = bar;
            }
            chips.Add(c);
            return c;
        }

        static Color OutlineColor(ChipKind k)
        {
            switch (k)
            {
                case ChipKind.Code: case ChipKind.Disguised: return Config.Green * 0.7f;
                case ChipKind.Feature: return Config.Blue;
                case ChipKind.Force: return Color.black;
                case ChipKind.Boss: return Config.Purple;
                default: return new Color(0, 0, 0, 0.5f);
            }
        }

        void RemoveChip(Chip c)
        {
            if (c.dead) return;
            c.dead = true;
            if (c.rt != null) Destroy(c.rt.gameObject);
        }

        // ============================ input ============================
        Vector2 ToCanvas(Vector2 s) { return new Vector2((s.x / Screen.width - 0.5f) * W, (s.y / Screen.height - 0.5f) * H); }
        bool InHud(Vector2 cp) { return cp.y > H * 0.5f - HudTotal; }

        void HandleSwipe(PointerState p)
        {
            Vector2 cur = ToCanvas(p.pos);
            if (p.down)
            {
                if (InHud(cur)) return;
                TapAt(cur); lastPtr = cur; trackingSwipe = true;
            }
            else if (p.held && trackingSwipe)
            {
                float dist = (cur - lastPtr).magnitude;
                if (dist < 12f) return;
                int steps = Mathf.CeilToInt(dist / 40f);
                for (int i = 1; i <= steps; i++) SlashAt(Vector2.Lerp(lastPtr, cur, i / (float)steps));
                FX_Burst(cur, new Color(1, 1, 1, 0.8f), 1, 30f);
                lastPtr = cur;
            }
        }

        bool Contains(Chip c, Vector2 pt)
        { return Mathf.Abs(pt.x - c.x) <= c.w * 0.5f + 24f && Mathf.Abs(pt.y - c.y) <= c.h * 0.5f + 24f; }

        void TapAt(Vector2 pt)
        {
            for (int i = chips.Count - 1; i >= 0; i--)
            {
                var c = chips[i];
                if (c.dead || !Contains(c, pt)) continue;
                c.cool = 0.15f; HitChip(c);
                return;     // a tap hits only the top-most chip
            }
        }

        void SlashAt(Vector2 pt)
        {
            int n = chips.Count;
            for (int i = n - 1; i >= 0; i--)
            {
                if (state != GState.Playing) return;
                var c = chips[i];
                if (c.dead || c.cool > 0f || !Contains(c, pt)) continue;
                c.cool = 0.15f; HitChip(c);
            }
        }

        // ============================ hit rules ============================
        int Multiplier() { return mult * (fever ? 2 : 1); }

        void AddScore(int pts, Vector2 pos, Color col)
        {
            int v = pts * Multiplier();
            score += v;
            FX_Float(pos, "+" + v, col);
        }

        void RegisterSquash(Vector2 pos)
        {
            combo++;
            if (combo % Config.StreakPerMultiplier == 0 && mult < Config.MaxMultiplier)
            {
                mult++;
                AudioManager.I.Play(Snd.Combo);
                FX_Float(pos + new Vector2(0, 70), "x" + mult + "!", Config.Gold);
                if (mult >= Config.MaxMultiplier && !fever) StartFever();
            }
        }

        void Squash(Chip c, int pts)
        {
            Vector2 pos = new Vector2(c.x, c.y);
            AddScore(pts, pos, Config.Green);
            RegisterSquash(pos);
            AudioManager.I.Play(Snd.Squash);
            FX_Burst(pos, c.kind == ChipKind.Disguised ? Config.Red : BaseColor(c.kind) * 1.4f, 14, 420f);
            RemoveChip(c);
        }

        void HitChip(Chip c)
        {
            Vector2 pos = new Vector2(c.x, c.y);
            switch (c.kind)
            {
                case ChipKind.Bug: Squash(c, 10); break;
                case ChipKind.Disguised: Squash(c, 20); break;
                case ChipKind.SplitChild: Squash(c, 8); break;

                case ChipKind.BigBug:
                    c.hp--;
                    if (c.hp <= 0) { Squash(c, 40); break; }
                    c.flash = 0.1f; c.vy = 120f;
                    AudioManager.I.Play(Snd.BossHit); FX_Burst(pos, Config.Red, 6, 300f); FX_Shake(6f);
                    UpdateChipLabel(c);
                    break;

                case ChipKind.Splitter:
                    AddScore(15, pos, Config.Green); RegisterSquash(pos);
                    AudioManager.I.Play(Snd.Jump);
                    FX_Burst(pos, Config.Orange, 10, 380f);
                    for (int s = -1; s <= 1; s += 2)
                    {
                        var kid = CreateChip(ChipKind.SplitChild, c.x, c.y, c.speed * 1.1f);
                        kid.vx = s * Random.Range(350f, 520f); kid.vy = Random.Range(500f, 750f);
                    }
                    RemoveChip(c);
                    break;

                case ChipKind.Code:
                case ChipKind.Feature:
                    FX_Burst(pos, Config.Red, 12, 380f);
                    FX_Float(pos, "DON'T TOUCH!", Config.Red);
                    RemoveChip(c);
                    Penalty(1f, c.kind == ChipKind.Code ? "You broke working code" : "You broke a feature");
                    break;

                case ChipKind.Force:
                    FX_Burst(pos, Config.Yellow, 40, 700f);
                    FX_Shake(40f); FX_Flash(Config.Yellow, 0.7f);
                    AudioManager.I.Play(Snd.ForcePush);
                    RemoveChip(c);
                    health = 0f; combo = 0; mult = 1;
                    GameOver("You ran git push --force");
                    break;

                case ChipKind.Heal:
                    health = Mathf.Min(Config.MaxHealth, health + 1f);
                    AudioManager.I.Play(Snd.Heal); FX_Burst(pos, Config.Green, 18, 380f);
                    FX_Float(pos, "BUILD HEALED", Config.Green); FX_Flash(Config.Green, 0.2f);
                    RemoveChip(c);
                    break;

                case ChipKind.Slow:
                    slowTimer = Config.SlowSeconds;
                    AudioManager.I.Play(Snd.Slow); FX_Burst(pos, Config.Blue, 18, 380f);
                    FX_Float(pos, "SLOW TIME", Config.Blue); FX_Flash(Config.Blue, 0.2f);
                    RemoveChip(c);
                    break;

                case ChipKind.FixAll: FixAll(c); break;

                case ChipKind.Boss:
                    c.hp--;
                    c.flash = 0.08f;
                    AudioManager.I.Play(Snd.BossHit); FX_Burst(pos, Config.Purple, 8, 360f); FX_Shake(8f);
                    if (c.hp <= 0) KillBoss(c); else UpdateChipLabel(c);
                    break;
            }
        }

        void UpdateChipLabel(Chip c)
        {
            if (c.hpBar != null) c.hpBar.fillAmount = Mathf.Clamp01(c.hp / (float)c.maxHp);
            if (c.kind == ChipKind.BigBug) c.label.text = c.baseName + " x" + c.hp;
        }

        void KillBoss(Chip c)
        {
            Vector2 pos = new Vector2(c.x, c.y);
            bossAlive = false;
            AddScore(300, pos, Config.Purple);
            health = Mathf.Min(Config.MaxHealth, health + 1f);
            AudioManager.I.Play(Snd.Explosion);
            FX_Burst(pos, Config.Purple, 50, 800f); FX_Shake(30f); FX_Flash(Config.Purple, 0.5f);
            FX_Float(pos + new Vector2(0, 90), "MONOLITH REFACTORED!", Config.Gold);
            RemoveChip(c);
        }

        void FixAll(Chip power)
        {
            Vector2 pos = new Vector2(power.x, power.y);
            RemoveChip(power);
            AudioManager.I.Play(Snd.PowerUp);
            AudioManager.I.Play(Snd.Explosion, 0.8f);
            FX_Shake(28f); FX_Flash(Config.Gold, 0.6f);
            FX_Float(pos, "FIX ALL!", Config.Gold);
            int n = chips.Count;
            for (int i = 0; i < n; i++)
            {
                var c = chips[i];
                if (c.dead || !IsBugKind(c.kind)) continue;
                Vector2 cp = new Vector2(c.x, c.y);
                if (c.kind == ChipKind.Boss)
                {
                    c.hp -= 5; c.flash = 0.15f;
                    FX_Burst(cp, Config.Purple, 20, 600f);
                    if (c.hp <= 0) KillBoss(c); else UpdateChipLabel(c);
                    continue;
                }
                AddScore(c.kind == ChipKind.BigBug ? 40 : 10, cp, Config.Gold);
                FX_Burst(cp, Config.Gold, 16, 520f);
                RemoveChip(c);
            }
        }

        // ============================ health, fever, game over ============================
        void Penalty(float amount, string reason)
        {
            health -= amount; combo = 0; mult = 1;
            if (fever) EndFever(false);
            AudioManager.I.Play(Snd.Hurt);
            FX_Shake(16f); FX_Flash(Config.Red, 0.45f);
#if UNITY_ANDROID && !UNITY_EDITOR
            Handheld.Vibrate();
#endif
            if (health <= 0.001f) { health = 0f; GameOver(reason); }
        }

        void StartFever()
        {
            fever = true; feverTimer = Config.FeverSeconds;
            AudioManager.I.Play(Snd.Fever);
            AudioManager.I.SetMusicPitch(1.1f);
            FX_Flash(Config.Gold, 0.4f);
            FX_Float(new Vector2(0, H * 0.5f - Config.HudHeight - 250f), "FEVER MODE! DOUBLE POINTS", Config.Gold);
        }

        void EndFever(bool timedOut)
        {
            fever = false; feverTimer = 0f;
            if (timedOut) { mult = 3; combo = 0; }
            AudioManager.I.SetMusicPitch(1f);
        }

        void GameOver(string reason)
        {
            overReason = reason;
            fever = false;
            newBest = score > best;
            if (newBest) { best = score; PlayerPrefs.SetInt("bb_best", best); PlayerPrefs.Save(); }
            AudioManager.I.Play(Snd.GameOver);
            SetState(GState.GameOver);
        }
    }
}
