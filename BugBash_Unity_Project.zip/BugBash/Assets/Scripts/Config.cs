using UnityEngine;

namespace BugBash
{
    public enum ChipKind { Bug, BigBug, Splitter, SplitChild, Disguised, Code, Feature, Force, Heal, Slow, FixAll, Boss }

    /// <summary>All tuning values, mirroring src/app/games/bug-bash/config.js of the web game.</summary>
    public static class Config
    {
        public const float RefWidth = 1080f;          // canvas is width-matched, height varies per phone
        public const float MaxHealth = 3f;
        public const float RampSeconds = 90f;         // game gets faster for the first 90 s
        public const float FallSpeedStart = 260f, FallSpeedEnd = 560f;
        public const float SpawnIntervalStart = 1.15f, SpawnIntervalEnd = 0.50f;
        public const float FirstBossAt = 40f, BossEvery = 60f;
        public const int StreakPerMultiplier = 3, MaxMultiplier = 5;
        public const float FeverSeconds = 8f;
        public const float SlowSeconds = 5f, SlowFactor = 0.4f;
        public const float SplitChildPenalty = 0.25f;
        public const float HudHeight = 210f;          // + safe-area inset
        public const float BottomLine = 150f;         // distance of the "main" line from the screen bottom
        public const int BossHp = 12, BigBugHp = 3;

        public static readonly string[] BugNames = { "NullReference", "off_by_one", "undefined", "segfault", "race_condition", "memory_leak", "typo_in_prod", "infinite_loop", "404_not_found", "stack_overflow" };
        public static readonly string[] BigBugNames = { "HeisenBug", "MemoryLeak", "DeadLock" };
        public static readonly string[] CodeNames = { "const sum = a + b;", "return result;", "export default App;", "import React;", "user.save();", "await db.close();", "if (ok) run();", "items.map(f);" };
        public static readonly string[] FeatureNames = { "feature: dark_mode", "feature: login", "feature: search", "feature: payments" };
        public const string ForceName = "(!) git push --force";
        public const string SplitName = "split_brain()";
        public const string BossName = "legacy_monolith.js";

        public static readonly string[] BackdropLines = {
            "function build() {", "  const tests = run();", "  if (tests.pass) {", "    deploy(main);", "  }", "  return status;",
            "}", "", "class Pipeline extends Job {", "  stage = 'green';", "  retry(n) { /* ... */ }", "}" };

        public static Color Hex(string h) { Color c; ColorUtility.TryParseHtmlString(h, out c); return c; }
        public static readonly Color Bg = Hex("#0d1117"), Panel = Hex("#161b22"), Border = Hex("#30363d"),
            Green = Hex("#3fb950"), Red = Hex("#f85149"), Blue = Hex("#58a6ff"), Yellow = Hex("#d29922"),
            Purple = Hex("#a371f7"), Text = Hex("#c9d1d9"), Orange = Hex("#db6d28"), Gold = Hex("#f2cc60");
    }
}
