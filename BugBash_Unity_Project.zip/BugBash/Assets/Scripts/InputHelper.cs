using UnityEngine;
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
using UnityEngine.InputSystem;
#endif

namespace BugBash
{
    public struct PointerState { public Vector2 pos; public bool down, held, up; }
    public enum GameKey { Start, Reset, Mute, Back }

    /// <summary>Touch + mouse + keyboard input that works with either Unity input backend.</summary>
    public static class InputHelper
    {
#if ENABLE_INPUT_SYSTEM && !ENABLE_LEGACY_INPUT_MANAGER
        public static PointerState Pointer()
        {
            var s = new PointerState();
            var ts = Touchscreen.current;
            if (ts != null)
            {
                var t = ts.primaryTouch;
                s.pos = t.position.ReadValue(); s.down = t.press.wasPressedThisFrame; s.held = t.press.isPressed; s.up = t.press.wasReleasedThisFrame;
                if (s.down || s.held || s.up) return s;
            }
            var m = Mouse.current;
            if (m != null)
            {
                s.pos = m.position.ReadValue(); s.down = m.leftButton.wasPressedThisFrame; s.held = m.leftButton.isPressed; s.up = m.leftButton.wasReleasedThisFrame;
            }
            return s;
        }
        public static bool KeyDown(GameKey k)
        {
            var kb = Keyboard.current; if (kb == null) return false;
            switch (k)
            {
                case GameKey.Start: return kb.spaceKey.wasPressedThisFrame;
                case GameKey.Reset: return kb.rKey.wasPressedThisFrame;
                case GameKey.Mute: return kb.mKey.wasPressedThisFrame;
                default: return kb.escapeKey.wasPressedThisFrame;   // Android Back button = Escape
            }
        }
#else
        public static PointerState Pointer()
        {
            var s = new PointerState();
            if (Input.touchCount > 0)
            {
                var t = Input.GetTouch(0);
                s.pos = t.position; s.down = t.phase == TouchPhase.Began;
                s.up = t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled; s.held = !s.up;
                return s;
            }
            s.pos = Input.mousePosition; s.down = Input.GetMouseButtonDown(0); s.held = Input.GetMouseButton(0); s.up = Input.GetMouseButtonUp(0);
            return s;
        }
        public static bool KeyDown(GameKey k)
        {
            switch (k)
            {
                case GameKey.Start: return Input.GetKeyDown(KeyCode.Space);
                case GameKey.Reset: return Input.GetKeyDown(KeyCode.R);
                case GameKey.Mute: return Input.GetKeyDown(KeyCode.M);
                default: return Input.GetKeyDown(KeyCode.Escape);
            }
        }
#endif
    }
}
