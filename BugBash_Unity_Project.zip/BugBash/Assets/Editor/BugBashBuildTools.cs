#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.Build;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace BugBash.EditorTools
{
    /// <summary>
    /// Menu: Bug Bash > 1. Setup Project for Android   (player settings + Main scene)
    ///       Bug Bash > 2. Build Android APK           (writes Builds/BugBash.apk)
    /// Command line: Unity -batchmode -quit -projectPath . -executeMethod BugBash.EditorTools.BugBashBuildTools.BuildAndroidCLI
    /// </summary>
    public static class BugBashBuildTools
    {
        const string ScenePath = "Assets/Scenes/Main.unity";

        [MenuItem("Bug Bash/1. Setup Project for Android")]
        public static void Setup()
        {
            PlayerSettings.companyName = "GCC FAST-NUCES Karachi";
            PlayerSettings.productName = "Bug Bash";
            PlayerSettings.SetApplicationIdentifier(NamedBuildTarget.Android, "com.gcc.bugbash");
            PlayerSettings.bundleVersion = "1.0.0";
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.Portrait;
            PlayerSettings.allowedAutorotateToPortrait = true;
            PlayerSettings.allowedAutorotateToPortraitUpsideDown = false;
            PlayerSettings.allowedAutorotateToLandscapeLeft = false;
            PlayerSettings.allowedAutorotateToLandscapeRight = false;
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
            PlayerSettings.SetScriptingBackend(NamedBuildTarget.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64 | AndroidArchitecture.ARMv7;

            Directory.CreateDirectory("Assets/Scenes");
            var scene = EditorSceneManager.NewScene(NewSceneSetup.DefaultGameObjects, NewSceneMode.Single);
            EditorSceneManager.SaveScene(scene, ScenePath);
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            AssetDatabase.SaveAssets();
            Debug.Log("Bug Bash: project set up. The game builds itself at runtime; press Play to test, or use Bug Bash > 2. Build Android APK.");
        }

        [MenuItem("Bug Bash/2. Build Android APK")]
        public static void BuildAndroid()
        {
            Setup();
            Directory.CreateDirectory("Builds");
            var opts = new BuildPlayerOptions
            {
                scenes = new[] { ScenePath },
                locationPathName = "Builds/BugBash.apk",
                target = BuildTarget.Android,
                options = BuildOptions.None
            };
            var report = BuildPipeline.BuildPlayer(opts);
            Debug.Log("Bug Bash build: " + report.summary.result + " -> " + report.summary.outputPath);
            if (report.summary.result != UnityEditor.Build.Reporting.BuildResult.Succeeded && Application.isBatchMode)
                EditorApplication.Exit(1);
        }

        public static void BuildAndroidCLI() { BuildAndroid(); }
    }
}
#endif
