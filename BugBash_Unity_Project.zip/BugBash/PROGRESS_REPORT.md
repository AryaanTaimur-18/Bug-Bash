# Bug Bash (Unity / Android): Development Progress Report

**Source:** `GCC-FAST-NUCES-Karachi/GCC` > `games.md` (Bug Bash section) and `src/app/games/bug-bash`
**Theme:** DON'T TOUCH: spare working code, features and `git push --force`.
**Overall status: ~85-90% (all features written; awaiting first compile / device test in Unity).**

## Milestones
| # | Milestone | Status | Deliverables |
|---|---|---|---|
| 1 | Foundation | Done | `Config.cs`, `InputHelper.cs`, `SpriteFactory.cs`, `Bootstrap.cs`, `Packages/manifest.json` |
| 2 | Audio | Done | `AudioManager.cs`: chiptune loop (132 BPM, Am-F-C-G) + 15 SFX, synthesised in code |
| 3 | Gameplay core | Done | `BugBashGame.cs` |
| 4 | UI, visuals, effects | Done | `BugBashGame.UI.cs`, `BugBashGame.FX.cs` |
| 5 | Android tooling + docs | Done | `Editor/BugBashBuildTools.cs`, README, this report |
| 6 | Compile, device test, balance | **Not started (needs Unity)** | n/a |

## Rules implemented (from games.md)
- Chips fall down a code file; a bug reaching the bottom costs 1 of 3 build health.
- Hitting working code or a feature costs 1 health; hitting `(!) git push --force` ends the run instantly.
- Every 3 squashes in a row raises the multiplier; reaching x5 starts fever (double points, 8 s). Any penalty resets the streak.
- Big bugs (3 hits), split bugs (break into 2 small bugs costing 0.25 health if they escape), disguised bugs (look like code, wavy red underline).
- Power-ups: heal, slow time, fix every bug on screen.
- `legacy_monolith.js` boss (12 hits) at 40 s then about every 60 s; costs 1 health if it survives to the bottom.
- Speed ramps up over the first 90 s. Tap one bug, or hold and drag to slash several.
- Best score and sound setting saved (PlayerPrefs). Pauses when the app loses focus. Low-memory phones get a lite effects mode.

## Audio list
Music loop; click; start; squash; boss hit; combo/multiplier up; hurt; explosion; force-push blast; power-up; heal; slow-time; fever; boss warning; **jump/boing** (split bugs hop apart); game over.

## Visuals
Scrolling code-editor backdrop, red "main" danger line, HUD (score, best, multiplier + combo bar, 3-segment health), colour-coded chips, particle bursts, floating score text, screen shake, colour flashes, fever gold pulse, slow-time blue tint.

## Known gaps and honest notes
- **Not compiled or run yet.** This environment has no Unity editor, so no APK could be produced; the code was written and reviewed by hand. Expect to fix a few compile errors on first open.
- The web version has no jumping character, so "jump" is implemented as the split-bug hop sound and motion.
- `CHIP_FALL=false` (pop-up-in-place mode) and the `?quality=` override are not ported.
- Procedural art and sound are functional, not final-polish. Replace with authored assets later if wanted.
- Tuning values are copied from `games.md` descriptions, not from `config.js` (not read); compare with the web game.
- Requires Unity 2022.2+ (uses the built-in `LegacyRuntime.ttf` font).

## Next steps
1. Open in Unity, fix any compile errors, run Setup, play in the editor.
2. Build the APK and test on a phone: touch feel, swipe hit radius, speed ramp, audio levels.
3. Balance against the web version; add app icon and splash screen.
